﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Форма "Договоры"
namespace Прокат
{
    public partial class Agreement : Form
    {
        public static string str = @"Provider=Microsoft.Ace.OLEDB.12.0;Data Source='D:\Study\3 курс\Практика ТРПО\Прокат\БД.accdb';";
        string comm = "Select * from Аренда";
        public Agreement()
        {
            InitializeComponent();

            OleDbConnection con = new OleDbConnection(str);
            con.Open();
            OleDbDataAdapter ad = new OleDbDataAdapter(comm, con);
            DataTable ds = new DataTable();
            ad.Fill(ds);
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = ds;
            con.Close();
        }

        private void labelClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void labelClose_MouseEnter(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.Red;
        }

        private void labelClose_MouseLeave(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.White;
        }
        Point lastPoint;

        private void panelAgreement_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panelAgreement_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void buttonClients_Click(object sender, EventArgs e)
        {
            Clients formClients = new Clients();
            formClients.Show();
            this.Hide();
        }

        private void buttonCar_Click(object sender, EventArgs e)
        {
            Cars formCars = new Cars();
            formCars.Show();
            this.Hide();
        }

        private void buttonCondition_Click(object sender, EventArgs e)
        {
            Condition formCondition = new Condition();
            formCondition.Show();
            this.Hide();
        }

        private void buttonPrice_Click(object sender, EventArgs e)
        {
            Price formPrice = new Price();
            formPrice.Show();
            this.Hide();
        }

        private void buttonAgreement_Click(object sender, EventArgs e)
        {
            Agreement formAgreement = new Agreement();
            formAgreement.Show();
            this.Hide();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            Main formMain = new Main();
            formMain.Show();
            this.Hide();
        }

        private void buttonchange_Click(object sender, EventArgs e)
        {
            Data_modification_Agreement formModificationAgreement = new Data_modification_Agreement();
            formModificationAgreement.Show();
        }
    }
}

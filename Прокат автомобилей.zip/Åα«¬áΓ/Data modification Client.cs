﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
//Форма "Модификация данных клиентов"
namespace Прокат
{
    public partial class Data_Modification_Client : Form
    {
        public static string str = @"Provider=Microsoft.Ace.OLEDB.12.0;Data Source='D:\Study\3 курс\Практика ТРПО\Прокат\БД.accdb';";
        //string comm = "Select * from Клиент";
        public Data_Modification_Client()
        {
            InitializeComponent();
        }
        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        Point lastPoint;

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }
        private void radioButtonAdd_CheckedChanged(object sender, EventArgs e)
        {
            textBoxId.Visible = true;
            textBoxFIO.Visible = true;
            textBoxPasport.Visible = true;
            textBoxTelephone.Visible = true;
            textBoxDriver.Visible = true;

            labelId.Visible = true;
            labelFIO.Visible = true;
            labelPasport.Visible = true;
            labelTelephone.Visible = true;
            labelDriver.Visible = true;
        }

        private void radioButtonUpdate_CheckedChanged(object sender, EventArgs e)
        {
            textBoxId.Visible = true;
            textBoxFIO.Visible = true;
            textBoxPasport.Visible = true;
            textBoxTelephone.Visible = true;
            textBoxDriver.Visible = true;

            labelId.Visible = true;
            labelFIO.Visible = true;
            labelPasport.Visible = true;
            labelTelephone.Visible = true;
            labelDriver.Visible = true;
        }
        private void radioButtonDelete_CheckedChanged_1(object sender, EventArgs e)
        {
            textBoxId.Visible = true;
            textBoxFIO.Visible = false;
            textBoxPasport.Visible = false;
            textBoxTelephone.Visible = false;
            textBoxDriver.Visible = false;

            labelId.Visible = true;
            labelFIO.Visible = false;
            labelPasport.Visible = false;
            labelTelephone.Visible = false;
            labelDriver.Visible = false;
        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection(str);
            con.Open();

            if (radioButtonAdd.Checked)
            {
                try
                {
                    string request = "INSERT INTO Клиент ([id_клиента], [ФИО], [Паспортные данные], [Телефон], [Категория водительских прав]) VALUES (@Id, @FIO, @Pasport, @Telephone, @Driver)";
                    OleDbCommand command = new OleDbCommand(request, con);
                    command.Parameters.AddWithValue("@Id", textBoxId.Text);
                    command.Parameters.AddWithValue("@FIO", textBoxFIO.Text);
                    command.Parameters.AddWithValue("@Psport", textBoxPasport.Text);
                    command.Parameters.AddWithValue("@Telephone", textBoxTelephone.Text);
                    command.Parameters.AddWithValue("@Driver", textBoxDriver.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно сохранены и обновлены в базе данных.", "Сообщение");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения данных: " + ex.Message);
                }

            }
            else if (radioButtonUpdate.Checked)
            {
                try
                {
                    string request = "UPDATE Клиент SET [ФИО] = @FIO, [Паспортные данные] = @Pasport, [Телефон] = @Telephone, [Категория водительских прав] = @Driver WHERE [id_клиента] = @Id";
                    OleDbCommand command = new OleDbCommand(request, con);
                    command.Parameters.AddWithValue("@FIO", textBoxFIO.Text);
                    command.Parameters.AddWithValue("@Pasport", textBoxPasport.Text);
                    command.Parameters.AddWithValue("@Telephone", textBoxTelephone.Text);
                    command.Parameters.AddWithValue("@Driver", textBoxDriver.Text);
                    command.Parameters.AddWithValue("@Id", textBoxId.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно сохранены и обновлены в базе данных.", "Сообщение");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения данных: " + ex.Message);
                }
            }
            else if (radioButtonDelete.Checked)
            {
                try
                {
                    string request = "DELETE FROM Клиент WHERE [id_клиента] = @Id";
                    OleDbCommand command = new OleDbCommand(request, con);
                    command.Parameters.AddWithValue("@Id", textBoxId.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно сохранены и обновлены в базе данных.", "Сообщение");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения данных: " + ex.Message);
                }
            }
            
            con.Close();
        }
    }
}


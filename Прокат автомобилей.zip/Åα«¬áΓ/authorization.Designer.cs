﻿namespace Прокат
{
    partial class authorization
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            labelClose = new Label();
            labelautoriz = new Label();
            panel2 = new Panel();
            pictureBoxPassword = new PictureBox();
            pictureBoxUser = new PictureBox();
            buttonEnter = new Button();
            textBoxPassword = new TextBox();
            textBoxLogin = new TextBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPassword).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxUser).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(24, 14, 127);
            panel1.Controls.Add(labelClose);
            panel1.Controls.Add(labelautoriz);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(398, 105);
            panel1.TabIndex = 0;
            // 
            // labelClose
            // 
            labelClose.AutoSize = true;
            labelClose.BackColor = Color.FromArgb(48, 50, 48);
            labelClose.Cursor = Cursors.Hand;
            labelClose.Font = new Font("PT Sans", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelClose.ForeColor = Color.White;
            labelClose.Location = new Point(376, 0);
            labelClose.Name = "labelClose";
            labelClose.Size = new Size(22, 26);
            labelClose.TabIndex = 9;
            labelClose.Text = "x";
            labelClose.Click += labelClose_Click;
            labelClose.MouseEnter += labelClose_MouseEnter;
            labelClose.MouseLeave += labelClose_MouseLeave;
            // 
            // labelautoriz
            // 
            labelautoriz.BackColor = Color.FromArgb(48, 50, 48);
            labelautoriz.Dock = DockStyle.Fill;
            labelautoriz.Font = new Font("Comic Sans MS", 25.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            labelautoriz.ForeColor = SystemColors.ButtonHighlight;
            labelautoriz.Location = new Point(0, 0);
            labelautoriz.Name = "labelautoriz";
            labelautoriz.Size = new Size(398, 105);
            labelautoriz.TabIndex = 10;
            labelautoriz.Text = "Авторизация";
            labelautoriz.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(96, 96, 96);
            panel2.Controls.Add(pictureBoxPassword);
            panel2.Controls.Add(pictureBoxUser);
            panel2.Controls.Add(buttonEnter);
            panel2.Controls.Add(textBoxPassword);
            panel2.Controls.Add(textBoxLogin);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(398, 405);
            panel2.TabIndex = 1;
            panel2.MouseDown += panel2_MouseDown;
            panel2.MouseMove += panel2_MouseMove;
            // 
            // pictureBoxPassword
            // 
            pictureBoxPassword.Image = Properties.Resources.password;
            pictureBoxPassword.Location = new Point(58, 232);
            pictureBoxPassword.Name = "pictureBoxPassword";
            pictureBoxPassword.Size = new Size(64, 64);
            pictureBoxPassword.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxPassword.TabIndex = 8;
            pictureBoxPassword.TabStop = false;
            // 
            // pictureBoxUser
            // 
            pictureBoxUser.Image = Properties.Resources.user;
            pictureBoxUser.Location = new Point(58, 122);
            pictureBoxUser.Name = "pictureBoxUser";
            pictureBoxUser.Size = new Size(64, 64);
            pictureBoxUser.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBoxUser.TabIndex = 7;
            pictureBoxUser.TabStop = false;
            // 
            // buttonEnter
            // 
            buttonEnter.Cursor = Cursors.Hand;
            buttonEnter.FlatAppearance.BorderColor = Color.FromArgb(150, 252, 0);
            buttonEnter.FlatAppearance.BorderSize = 2;
            buttonEnter.FlatAppearance.MouseDownBackColor = Color.FromArgb(21, 123, 19);
            buttonEnter.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonEnter.FlatStyle = FlatStyle.Flat;
            buttonEnter.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            buttonEnter.Location = new Point(102, 326);
            buttonEnter.Name = "buttonEnter";
            buttonEnter.Size = new Size(211, 41);
            buttonEnter.TabIndex = 5;
            buttonEnter.Text = "Войти";
            buttonEnter.UseVisualStyleBackColor = true;
            buttonEnter.Click += buttonEnter_Click;
            // 
            // textBoxPassword
            // 
            textBoxPassword.Cursor = Cursors.IBeam;
            textBoxPassword.Font = new Font("PT Sans", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxPassword.Location = new Point(147, 244);
            textBoxPassword.Name = "textBoxPassword";
            textBoxPassword.Size = new Size(166, 42);
            textBoxPassword.TabIndex = 4;
            textBoxPassword.UseSystemPasswordChar = true;
            // 
            // textBoxLogin
            // 
            textBoxLogin.Cursor = Cursors.IBeam;
            textBoxLogin.Font = new Font("PT Sans", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxLogin.Location = new Point(147, 135);
            textBoxLogin.Multiline = true;
            textBoxLogin.Name = "textBoxLogin";
            textBoxLogin.Size = new Size(166, 42);
            textBoxLogin.TabIndex = 3;
            // 
            // authorization
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(398, 408);
            Controls.Add(panel1);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "authorization";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Авторизация";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxPassword).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxUser).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Button buttonEnter;
        private TextBox textBoxPassword;
        private TextBox textBoxLogin;
        private PictureBox pictureBoxUser;
        private PictureBox pictureBoxPassword;
        private Label labelClose;
        private Label labelautoriz;
    }
}
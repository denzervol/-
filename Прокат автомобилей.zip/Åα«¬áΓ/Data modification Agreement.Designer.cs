﻿namespace Прокат
{
    partial class Data_modification_Agreement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            labelEnd = new Label();
            labelStart = new Label();
            labelIdCar = new Label();
            labelIdClient = new Label();
            textBoxEnd = new TextBox();
            textBoxStart = new TextBox();
            textBoxIdCar = new TextBox();
            textBoxIdClient = new TextBox();
            radioButtonDelete = new RadioButton();
            radioButtonAdd = new RadioButton();
            buttonEnter = new Button();
            buttonClose = new Button();
            panel2 = new Panel();
            labelDataModification = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(96, 96, 96);
            panel1.Controls.Add(labelEnd);
            panel1.Controls.Add(labelStart);
            panel1.Controls.Add(labelIdCar);
            panel1.Controls.Add(labelIdClient);
            panel1.Controls.Add(textBoxEnd);
            panel1.Controls.Add(textBoxStart);
            panel1.Controls.Add(textBoxIdCar);
            panel1.Controls.Add(textBoxIdClient);
            panel1.Controls.Add(radioButtonDelete);
            panel1.Controls.Add(radioButtonAdd);
            panel1.Controls.Add(buttonEnter);
            panel1.Controls.Add(buttonClose);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(895, 484);
            panel1.TabIndex = 1;
            panel1.MouseDown += panel1_MouseDown;
            panel1.MouseMove += panel1_MouseMove;
            // 
            // labelEnd
            // 
            labelEnd.AutoSize = true;
            labelEnd.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelEnd.Location = new Point(502, 316);
            labelEnd.Name = "labelEnd";
            labelEnd.Size = new Size(162, 28);
            labelEnd.TabIndex = 24;
            labelEnd.Text = "Дата окончания";
            // 
            // labelStart
            // 
            labelStart.AutoSize = true;
            labelStart.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelStart.Location = new Point(486, 204);
            labelStart.Name = "labelStart";
            labelStart.Size = new Size(178, 28);
            labelStart.TabIndex = 23;
            labelStart.Text = "Дата заключения";
            // 
            // labelIdCar
            // 
            labelIdCar.AutoSize = true;
            labelIdCar.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelIdCar.Location = new Point(513, 258);
            labelIdCar.Name = "labelIdCar";
            labelIdCar.Size = new Size(151, 28);
            labelIdCar.TabIndex = 22;
            labelIdCar.Text = "id автомобиля";
            // 
            // labelIdClient
            // 
            labelIdClient.AutoSize = true;
            labelIdClient.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelIdClient.Location = new Point(551, 151);
            labelIdClient.Name = "labelIdClient";
            labelIdClient.Size = new Size(113, 28);
            labelIdClient.TabIndex = 21;
            labelIdClient.Text = "id клиента";
            // 
            // textBoxEnd
            // 
            textBoxEnd.Location = new Point(690, 316);
            textBoxEnd.Name = "textBoxEnd";
            textBoxEnd.Size = new Size(156, 27);
            textBoxEnd.TabIndex = 2;
            // 
            // textBoxStart
            // 
            textBoxStart.Location = new Point(690, 207);
            textBoxStart.Name = "textBoxStart";
            textBoxStart.Size = new Size(156, 27);
            textBoxStart.TabIndex = 3;
            // 
            // textBoxIdCar
            // 
            textBoxIdCar.Location = new Point(690, 259);
            textBoxIdCar.Name = "textBoxIdCar";
            textBoxIdCar.Size = new Size(156, 27);
            textBoxIdCar.TabIndex = 4;
            // 
            // textBoxIdClient
            // 
            textBoxIdClient.Location = new Point(690, 151);
            textBoxIdClient.Name = "textBoxIdClient";
            textBoxIdClient.Size = new Size(156, 27);
            textBoxIdClient.TabIndex = 5;
            // 
            // radioButtonDelete
            // 
            radioButtonDelete.AutoSize = true;
            radioButtonDelete.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButtonDelete.Location = new Point(90, 259);
            radioButtonDelete.Name = "radioButtonDelete";
            radioButtonDelete.Size = new Size(197, 32);
            radioButtonDelete.TabIndex = 1;
            radioButtonDelete.TabStop = true;
            radioButtonDelete.Text = "Удалить договор";
            radioButtonDelete.UseVisualStyleBackColor = true;
            radioButtonDelete.CheckedChanged += radioButtonDelete_CheckedChanged;
            // 
            // radioButtonAdd
            // 
            radioButtonAdd.AutoSize = true;
            radioButtonAdd.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButtonAdd.Location = new Point(90, 188);
            radioButtonAdd.Name = "radioButtonAdd";
            radioButtonAdd.Size = new Size(207, 32);
            radioButtonAdd.TabIndex = 0;
            radioButtonAdd.TabStop = true;
            radioButtonAdd.Text = "Добавить договор";
            radioButtonAdd.UseVisualStyleBackColor = true;
            radioButtonAdd.CheckedChanged += radioButtonAdd_CheckedChanged;
            // 
            // buttonEnter
            // 
            buttonEnter.FlatAppearance.BorderColor = Color.FromArgb(150, 252, 0);
            buttonEnter.FlatAppearance.BorderSize = 2;
            buttonEnter.FlatAppearance.MouseDownBackColor = Color.FromArgb(21, 123, 19);
            buttonEnter.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonEnter.FlatStyle = FlatStyle.Flat;
            buttonEnter.Font = new Font("Comic Sans MS", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            buttonEnter.Location = new Point(655, 398);
            buttonEnter.Name = "buttonEnter";
            buttonEnter.Size = new Size(191, 32);
            buttonEnter.TabIndex = 20;
            buttonEnter.Text = "Сохранить";
            buttonEnter.UseVisualStyleBackColor = true;
            buttonEnter.Click += buttonEnter_Click;
            // 
            // buttonClose
            // 
            buttonClose.FlatAppearance.BorderColor = Color.FromArgb(150, 252, 0);
            buttonClose.FlatAppearance.BorderSize = 2;
            buttonClose.FlatAppearance.MouseDownBackColor = Color.FromArgb(21, 123, 19);
            buttonClose.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonClose.FlatStyle = FlatStyle.Flat;
            buttonClose.Font = new Font("Comic Sans MS", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            buttonClose.Location = new Point(39, 398);
            buttonClose.Name = "buttonClose";
            buttonClose.Size = new Size(191, 32);
            buttonClose.TabIndex = 19;
            buttonClose.Text = "Закрыть";
            buttonClose.UseVisualStyleBackColor = true;
            buttonClose.Click += buttonClose_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(48, 50, 48);
            panel2.Controls.Add(labelDataModification);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(895, 77);
            panel2.TabIndex = 0;
            // 
            // labelDataModification
            // 
            labelDataModification.Dock = DockStyle.Fill;
            labelDataModification.Font = new Font("Comic Sans MS", 24F, FontStyle.Regular, GraphicsUnit.Point);
            labelDataModification.ForeColor = Color.White;
            labelDataModification.Location = new Point(0, 0);
            labelDataModification.Name = "labelDataModification";
            labelDataModification.Size = new Size(895, 77);
            labelDataModification.TabIndex = 0;
            labelDataModification.Text = "Модификация данных договоров";
            labelDataModification.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Data_modification_Agreement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(895, 484);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Data_modification_Agreement";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Data_modification_Agreement";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button buttonEnter;
        private Button buttonClose;
        private Panel panel2;
        private Label labelDataModification;
        private RadioButton radioButtonDelete;
        private RadioButton radioButtonAdd;
        private Label labelEnd;
        private Label labelStart;
        private Label labelIdCar;
        private Label labelIdClient;
        private TextBox textBoxEnd;
        private TextBox textBoxStart;
        private TextBox textBoxIdCar;
        private TextBox textBoxIdClient;
    }
}
﻿namespace Прокат
{
    partial class Data_Modification_Condition
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            labelPrice = new Label();
            labelDate = new Label();
            labelIdCar = new Label();
            textBoxWork = new TextBox();
            textBoxDate = new TextBox();
            textBoxIdCar = new TextBox();
            buttonEnter = new Button();
            buttonClose = new Button();
            panel2 = new Panel();
            labelDataModification = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(96, 96, 96);
            panel1.Controls.Add(labelPrice);
            panel1.Controls.Add(labelDate);
            panel1.Controls.Add(labelIdCar);
            panel1.Controls.Add(textBoxWork);
            panel1.Controls.Add(textBoxDate);
            panel1.Controls.Add(textBoxIdCar);
            panel1.Controls.Add(buttonEnter);
            panel1.Controls.Add(buttonClose);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 450);
            panel1.TabIndex = 3;
            panel1.MouseDown += panel1_MouseDown;
            panel1.MouseMove += panel1_MouseMove;
            // 
            // labelPrice
            // 
            labelPrice.AutoSize = true;
            labelPrice.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelPrice.Location = new Point(143, 280);
            labelPrice.Name = "labelPrice";
            labelPrice.Size = new Size(80, 28);
            labelPrice.TabIndex = 24;
            labelPrice.Text = "Работы";
            // 
            // labelDate
            // 
            labelDate.AutoSize = true;
            labelDate.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelDate.Location = new Point(32, 205);
            labelDate.Name = "labelDate";
            labelDate.Size = new Size(319, 28);
            labelDate.TabIndex = 23;
            labelDate.Text = "Дата последнего обслуживания";
            // 
            // labelIdCar
            // 
            labelIdCar.AutoSize = true;
            labelIdCar.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelIdCar.Location = new Point(116, 120);
            labelIdCar.Name = "labelIdCar";
            labelIdCar.Size = new Size(151, 28);
            labelIdCar.TabIndex = 22;
            labelIdCar.Text = "id автомобиля";
            // 
            // textBoxWork
            // 
            textBoxWork.Location = new Point(390, 283);
            textBoxWork.Name = "textBoxWork";
            textBoxWork.Size = new Size(366, 27);
            textBoxWork.TabIndex = 2;
            // 
            // textBoxDate
            // 
            textBoxDate.Location = new Point(390, 206);
            textBoxDate.Name = "textBoxDate";
            textBoxDate.Size = new Size(366, 27);
            textBoxDate.TabIndex = 3;
            // 
            // textBoxIdCar
            // 
            textBoxIdCar.Location = new Point(390, 123);
            textBoxIdCar.Name = "textBoxIdCar";
            textBoxIdCar.Size = new Size(366, 27);
            textBoxIdCar.TabIndex = 4;
            // 
            // buttonEnter
            // 
            buttonEnter.FlatAppearance.BorderColor = Color.FromArgb(150, 252, 0);
            buttonEnter.FlatAppearance.BorderSize = 2;
            buttonEnter.FlatAppearance.MouseDownBackColor = Color.FromArgb(21, 123, 19);
            buttonEnter.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonEnter.FlatStyle = FlatStyle.Flat;
            buttonEnter.Font = new Font("Comic Sans MS", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            buttonEnter.Location = new Point(565, 376);
            buttonEnter.Name = "buttonEnter";
            buttonEnter.Size = new Size(191, 32);
            buttonEnter.TabIndex = 20;
            buttonEnter.Text = "Сохранить";
            buttonEnter.UseVisualStyleBackColor = true;
            buttonEnter.Click += buttonEnter_Click;
            // 
            // buttonClose
            // 
            buttonClose.FlatAppearance.BorderColor = Color.FromArgb(150, 252, 0);
            buttonClose.FlatAppearance.BorderSize = 2;
            buttonClose.FlatAppearance.MouseDownBackColor = Color.FromArgb(21, 123, 19);
            buttonClose.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonClose.FlatStyle = FlatStyle.Flat;
            buttonClose.Font = new Font("Comic Sans MS", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            buttonClose.Location = new Point(32, 376);
            buttonClose.Name = "buttonClose";
            buttonClose.Size = new Size(191, 32);
            buttonClose.TabIndex = 19;
            buttonClose.Text = "Закрыть";
            buttonClose.UseVisualStyleBackColor = true;
            buttonClose.Click += buttonClose_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(48, 50, 48);
            panel2.Controls.Add(labelDataModification);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(800, 77);
            panel2.TabIndex = 0;
            // 
            // labelDataModification
            // 
            labelDataModification.Dock = DockStyle.Fill;
            labelDataModification.Font = new Font("Comic Sans MS", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            labelDataModification.ForeColor = Color.White;
            labelDataModification.Location = new Point(0, 0);
            labelDataModification.Name = "labelDataModification";
            labelDataModification.Size = new Size(800, 77);
            labelDataModification.TabIndex = 0;
            labelDataModification.Text = "Модификация данных состояний автомобилей";
            labelDataModification.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Data_Modification_Condition
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Data_Modification_Condition";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Data_Modification_Condition";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label labelPrice;
        private Label labelDate;
        private Label labelIdCar;
        private TextBox textBoxWork;
        private TextBox textBoxDate;
        private TextBox textBoxIdCar;
        private Button buttonEnter;
        private Button buttonClose;
        private Panel panel2;
        private Label labelDataModification;
    }
}
﻿namespace Прокат
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            labelClose = new Label();
            labelHome = new Label();
            labelChoise = new Label();
            buttonEnterClients = new Button();
            buttonEnterCars = new Button();
            buttonConditionCars = new Button();
            panelMain = new Panel();
            buttonAddAgreement = new Button();
            buttonAddPrice = new Button();
            panel2.SuspendLayout();
            panelMain.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(15, 20, 73);
            panel2.Controls.Add(labelClose);
            panel2.Controls.Add(labelHome);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(820, 66);
            panel2.TabIndex = 2;
            // 
            // labelClose
            // 
            labelClose.Cursor = Cursors.Hand;
            labelClose.Dock = DockStyle.Right;
            labelClose.Font = new Font("PT Sans", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelClose.ForeColor = Color.White;
            labelClose.ImageAlign = ContentAlignment.TopRight;
            labelClose.Location = new Point(798, 0);
            labelClose.Name = "labelClose";
            labelClose.Size = new Size(22, 66);
            labelClose.TabIndex = 10;
            labelClose.Text = "x";
            labelClose.Click += labelClose_Click;
            labelClose.MouseEnter += labelClose_MouseEnter;
            labelClose.MouseLeave += labelClose_MouseLeave;
            // 
            // labelHome
            // 
            labelHome.Dock = DockStyle.Fill;
            labelHome.Font = new Font("Comic Sans MS", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            labelHome.ForeColor = Color.White;
            labelHome.Location = new Point(0, 0);
            labelHome.Name = "labelHome";
            labelHome.Size = new Size(820, 66);
            labelHome.TabIndex = 0;
            labelHome.Text = "Главная";
            labelHome.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labelChoise
            // 
            labelChoise.AutoSize = true;
            labelChoise.Font = new Font("Comic Sans MS", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            labelChoise.Location = new Point(240, 3);
            labelChoise.Name = "labelChoise";
            labelChoise.Size = new Size(340, 47);
            labelChoise.TabIndex = 3;
            labelChoise.Text = "Выберите действия";
            labelChoise.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // buttonEnterClients
            // 
            buttonEnterClients.BackColor = Color.Coral;
            buttonEnterClients.Cursor = Cursors.Hand;
            buttonEnterClients.FlatAppearance.BorderSize = 2;
            buttonEnterClients.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonEnterClients.FlatStyle = FlatStyle.Flat;
            buttonEnterClients.Font = new Font("Comic Sans MS", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            buttonEnterClients.ForeColor = Color.White;
            buttonEnterClients.Location = new Point(240, 81);
            buttonEnterClients.Name = "buttonEnterClients";
            buttonEnterClients.Size = new Size(340, 50);
            buttonEnterClients.TabIndex = 4;
            buttonEnterClients.Text = "Данные клиентов";
            buttonEnterClients.UseVisualStyleBackColor = false;
            buttonEnterClients.Click += buttonEnterClients_Click;
            // 
            // buttonEnterCars
            // 
            buttonEnterCars.BackColor = Color.Coral;
            buttonEnterCars.Cursor = Cursors.Hand;
            buttonEnterCars.FlatAppearance.BorderSize = 2;
            buttonEnterCars.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonEnterCars.FlatStyle = FlatStyle.Flat;
            buttonEnterCars.Font = new Font("Comic Sans MS", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            buttonEnterCars.ForeColor = Color.White;
            buttonEnterCars.Location = new Point(240, 166);
            buttonEnterCars.Name = "buttonEnterCars";
            buttonEnterCars.Size = new Size(340, 50);
            buttonEnterCars.TabIndex = 5;
            buttonEnterCars.Text = "Данные автомобилей";
            buttonEnterCars.UseVisualStyleBackColor = false;
            buttonEnterCars.Click += buttonEnterCars_Click;
            // 
            // buttonConditionCars
            // 
            buttonConditionCars.BackColor = Color.Coral;
            buttonConditionCars.Cursor = Cursors.Hand;
            buttonConditionCars.FlatAppearance.BorderSize = 2;
            buttonConditionCars.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonConditionCars.FlatStyle = FlatStyle.Flat;
            buttonConditionCars.Font = new Font("Comic Sans MS", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            buttonConditionCars.ForeColor = Color.White;
            buttonConditionCars.Location = new Point(240, 239);
            buttonConditionCars.Name = "buttonConditionCars";
            buttonConditionCars.Size = new Size(340, 50);
            buttonConditionCars.TabIndex = 6;
            buttonConditionCars.Text = "Состояние автомобилей";
            buttonConditionCars.UseVisualStyleBackColor = false;
            buttonConditionCars.Click += buttonConditionCars_Click_1;
            // 
            // panelMain
            // 
            panelMain.BackColor = Color.White;
            panelMain.Controls.Add(labelChoise);
            panelMain.Controls.Add(buttonAddAgreement);
            panelMain.Controls.Add(buttonAddPrice);
            panelMain.Controls.Add(buttonConditionCars);
            panelMain.Controls.Add(buttonEnterClients);
            panelMain.Controls.Add(buttonEnterCars);
            panelMain.Dock = DockStyle.Top;
            panelMain.Location = new Point(0, 66);
            panelMain.Name = "panelMain";
            panelMain.Size = new Size(820, 480);
            panelMain.TabIndex = 7;
            panelMain.MouseDown += panelMain_MouseDown;
            panelMain.MouseMove += panelMain_MouseMove;
            // 
            // buttonAddAgreement
            // 
            buttonAddAgreement.BackColor = Color.Coral;
            buttonAddAgreement.Cursor = Cursors.Hand;
            buttonAddAgreement.FlatAppearance.BorderSize = 2;
            buttonAddAgreement.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonAddAgreement.FlatStyle = FlatStyle.Flat;
            buttonAddAgreement.Font = new Font("Comic Sans MS", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            buttonAddAgreement.ForeColor = Color.White;
            buttonAddAgreement.Location = new Point(240, 398);
            buttonAddAgreement.Name = "buttonAddAgreement";
            buttonAddAgreement.Size = new Size(340, 50);
            buttonAddAgreement.TabIndex = 8;
            buttonAddAgreement.Text = "Договоры";
            buttonAddAgreement.UseVisualStyleBackColor = false;
            buttonAddAgreement.Click += buttonAddAgreement_Click;
            // 
            // buttonAddPrice
            // 
            buttonAddPrice.BackColor = Color.Coral;
            buttonAddPrice.Cursor = Cursors.Hand;
            buttonAddPrice.FlatAppearance.BorderSize = 2;
            buttonAddPrice.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonAddPrice.FlatStyle = FlatStyle.Flat;
            buttonAddPrice.Font = new Font("Comic Sans MS", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            buttonAddPrice.ForeColor = Color.White;
            buttonAddPrice.Location = new Point(240, 320);
            buttonAddPrice.Name = "buttonAddPrice";
            buttonAddPrice.Size = new Size(340, 50);
            buttonAddPrice.TabIndex = 7;
            buttonAddPrice.Text = "Цена автомобилей";
            buttonAddPrice.UseVisualStyleBackColor = false;
            buttonAddPrice.Click += buttonAddPrice_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(820, 546);
            Controls.Add(panelMain);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Main";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Главная";
            panel2.ResumeLayout(false);
            panelMain.ResumeLayout(false);
            panelMain.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private Panel panel2;
        private Label labelHome;
        private Label labelChoise;
        private Button buttonEnterClients;
        private Button buttonEnterCars;
        private Button buttonConditionCars;
        private Label labelClose;
        private Panel panelMain;
        private Button buttonAddPrice;
        private Button buttonAddAgreement;
    }
}
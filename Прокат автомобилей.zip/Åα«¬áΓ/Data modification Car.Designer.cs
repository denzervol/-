﻿namespace Прокат
{
    partial class Data_modification_Car
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            radioButtonDelete = new RadioButton();
            buttonEnter = new Button();
            radioButtonUpdate = new RadioButton();
            radioButtonAdd = new RadioButton();
            buttonClose = new Button();
            labelTransmission = new Label();
            labelYear = new Label();
            labelColor = new Label();
            labelModel = new Label();
            labelMarka = new Label();
            textBoxModel = new TextBox();
            textBoxMarka = new TextBox();
            textBoxColor = new TextBox();
            textBoxYear = new TextBox();
            textBoxTransmission = new TextBox();
            labelStatus = new Label();
            textBoxStatus = new TextBox();
            labelId = new Label();
            textBoxId = new TextBox();
            panel2 = new Panel();
            labelDataModification = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(96, 96, 96);
            panel1.Controls.Add(radioButtonDelete);
            panel1.Controls.Add(buttonEnter);
            panel1.Controls.Add(radioButtonUpdate);
            panel1.Controls.Add(radioButtonAdd);
            panel1.Controls.Add(buttonClose);
            panel1.Controls.Add(labelTransmission);
            panel1.Controls.Add(labelYear);
            panel1.Controls.Add(labelColor);
            panel1.Controls.Add(labelModel);
            panel1.Controls.Add(labelMarka);
            panel1.Controls.Add(textBoxModel);
            panel1.Controls.Add(textBoxMarka);
            panel1.Controls.Add(textBoxColor);
            panel1.Controls.Add(textBoxYear);
            panel1.Controls.Add(textBoxTransmission);
            panel1.Controls.Add(labelStatus);
            panel1.Controls.Add(textBoxStatus);
            panel1.Controls.Add(labelId);
            panel1.Controls.Add(textBoxId);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(851, 586);
            panel1.TabIndex = 1;
            panel1.MouseDown += panel1_MouseDown;
            panel1.MouseMove += panel1_MouseMove;
            // 
            // radioButtonDelete
            // 
            radioButtonDelete.AutoSize = true;
            radioButtonDelete.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButtonDelete.Location = new Point(77, 321);
            radioButtonDelete.Name = "radioButtonDelete";
            radioButtonDelete.Size = new Size(234, 32);
            radioButtonDelete.TabIndex = 7;
            radioButtonDelete.TabStop = true;
            radioButtonDelete.Text = "Удалить автомобиль";
            radioButtonDelete.UseVisualStyleBackColor = true;
            radioButtonDelete.CheckedChanged += radioButtonDelete_CheckedChanged;
            // 
            // buttonEnter
            // 
            buttonEnter.FlatAppearance.BorderColor = Color.FromArgb(150, 252, 0);
            buttonEnter.FlatAppearance.BorderSize = 2;
            buttonEnter.FlatAppearance.MouseDownBackColor = Color.FromArgb(21, 123, 19);
            buttonEnter.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonEnter.FlatStyle = FlatStyle.Flat;
            buttonEnter.Font = new Font("Comic Sans MS", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            buttonEnter.Location = new Point(622, 524);
            buttonEnter.Name = "buttonEnter";
            buttonEnter.Size = new Size(191, 32);
            buttonEnter.TabIndex = 20;
            buttonEnter.Text = "Сохранить";
            buttonEnter.UseVisualStyleBackColor = true;
            buttonEnter.Click += buttonEnter_Click;
            // 
            // radioButtonUpdate
            // 
            radioButtonUpdate.AutoSize = true;
            radioButtonUpdate.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButtonUpdate.Location = new Point(77, 267);
            radioButtonUpdate.Name = "radioButtonUpdate";
            radioButtonUpdate.Size = new Size(189, 32);
            radioButtonUpdate.TabIndex = 6;
            radioButtonUpdate.TabStop = true;
            radioButtonUpdate.Text = "Обновить статус";
            radioButtonUpdate.UseVisualStyleBackColor = true;
            radioButtonUpdate.CheckedChanged += radioButtonUpdate_CheckedChanged;
            // 
            // radioButtonAdd
            // 
            radioButtonAdd.AutoSize = true;
            radioButtonAdd.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButtonAdd.Location = new Point(77, 216);
            radioButtonAdd.Name = "radioButtonAdd";
            radioButtonAdd.Size = new Size(244, 32);
            radioButtonAdd.TabIndex = 5;
            radioButtonAdd.TabStop = true;
            radioButtonAdd.Text = "Добавить автомобиль";
            radioButtonAdd.UseVisualStyleBackColor = true;
            radioButtonAdd.CheckedChanged += radioButtonAdd_CheckedChanged;
            // 
            // buttonClose
            // 
            buttonClose.FlatAppearance.BorderColor = Color.FromArgb(150, 252, 0);
            buttonClose.FlatAppearance.BorderSize = 2;
            buttonClose.FlatAppearance.MouseDownBackColor = Color.FromArgb(21, 123, 19);
            buttonClose.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonClose.FlatStyle = FlatStyle.Flat;
            buttonClose.Font = new Font("Comic Sans MS", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            buttonClose.Location = new Point(43, 524);
            buttonClose.Name = "buttonClose";
            buttonClose.Size = new Size(191, 32);
            buttonClose.TabIndex = 19;
            buttonClose.Text = "Закрыть";
            buttonClose.UseVisualStyleBackColor = true;
            buttonClose.Click += buttonClose_Click;
            // 
            // labelTransmission
            // 
            labelTransmission.AutoSize = true;
            labelTransmission.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelTransmission.Location = new Point(405, 450);
            labelTransmission.Name = "labelTransmission";
            labelTransmission.Size = new Size(222, 28);
            labelTransmission.TabIndex = 17;
            labelTransmission.Text = "Тип коробки передач";
            // 
            // labelYear
            // 
            labelYear.AutoSize = true;
            labelYear.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelYear.Location = new Point(494, 397);
            labelYear.Name = "labelYear";
            labelYear.Size = new Size(133, 28);
            labelYear.TabIndex = 16;
            labelYear.Text = "Год выпуска";
            // 
            // labelColor
            // 
            labelColor.AutoSize = true;
            labelColor.Font = new Font("Comic Sans MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            labelColor.Location = new Point(559, 344);
            labelColor.Name = "labelColor";
            labelColor.Size = new Size(68, 31);
            labelColor.TabIndex = 15;
            labelColor.Text = "Цвет";
            // 
            // labelModel
            // 
            labelModel.AutoSize = true;
            labelModel.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelModel.Location = new Point(556, 290);
            labelModel.Name = "labelModel";
            labelModel.Size = new Size(71, 28);
            labelModel.TabIndex = 14;
            labelModel.Text = "Марка";
            // 
            // labelMarka
            // 
            labelMarka.AutoSize = true;
            labelMarka.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelMarka.Location = new Point(539, 235);
            labelMarka.Name = "labelMarka";
            labelMarka.Size = new Size(88, 28);
            labelMarka.TabIndex = 13;
            labelMarka.Text = "Модель";
            // 
            // textBoxModel
            // 
            textBoxModel.Location = new Point(657, 238);
            textBoxModel.Name = "textBoxModel";
            textBoxModel.Size = new Size(156, 27);
            textBoxModel.TabIndex = 12;
            // 
            // textBoxMarka
            // 
            textBoxMarka.Location = new Point(657, 293);
            textBoxMarka.Name = "textBoxMarka";
            textBoxMarka.Size = new Size(156, 27);
            textBoxMarka.TabIndex = 11;
            // 
            // textBoxColor
            // 
            textBoxColor.Location = new Point(657, 344);
            textBoxColor.Name = "textBoxColor";
            textBoxColor.Size = new Size(156, 27);
            textBoxColor.TabIndex = 10;
            // 
            // textBoxYear
            // 
            textBoxYear.Location = new Point(657, 400);
            textBoxYear.Name = "textBoxYear";
            textBoxYear.Size = new Size(156, 27);
            textBoxYear.TabIndex = 9;
            // 
            // textBoxTransmission
            // 
            textBoxTransmission.Location = new Point(657, 453);
            textBoxTransmission.Name = "textBoxTransmission";
            textBoxTransmission.Size = new Size(156, 27);
            textBoxTransmission.TabIndex = 8;
            // 
            // labelStatus
            // 
            labelStatus.AutoSize = true;
            labelStatus.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelStatus.Location = new Point(555, 184);
            labelStatus.Name = "labelStatus";
            labelStatus.Size = new Size(72, 28);
            labelStatus.TabIndex = 4;
            labelStatus.Text = "Статус";
            // 
            // textBoxStatus
            // 
            textBoxStatus.Location = new Point(657, 187);
            textBoxStatus.Name = "textBoxStatus";
            textBoxStatus.Size = new Size(156, 27);
            textBoxStatus.TabIndex = 3;
            // 
            // labelId
            // 
            labelId.AutoSize = true;
            labelId.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelId.Location = new Point(471, 133);
            labelId.Name = "labelId";
            labelId.Size = new Size(156, 28);
            labelId.TabIndex = 2;
            labelId.Text = "Id автомобиля";
            // 
            // textBoxId
            // 
            textBoxId.Location = new Point(657, 136);
            textBoxId.Name = "textBoxId";
            textBoxId.Size = new Size(156, 27);
            textBoxId.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(48, 50, 48);
            panel2.Controls.Add(labelDataModification);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(851, 77);
            panel2.TabIndex = 0;
            // 
            // labelDataModification
            // 
            labelDataModification.Dock = DockStyle.Fill;
            labelDataModification.Font = new Font("Comic Sans MS", 24F, FontStyle.Regular, GraphicsUnit.Point);
            labelDataModification.ForeColor = Color.White;
            labelDataModification.Location = new Point(0, 0);
            labelDataModification.Name = "labelDataModification";
            labelDataModification.Size = new Size(851, 77);
            labelDataModification.TabIndex = 0;
            labelDataModification.Text = "Модификация данных автомобилей";
            labelDataModification.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Data_modification_Car
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(851, 586);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Data_modification_Car";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Data_modification_Car";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private RadioButton radioButtonDelete;
        private Button buttonEnter;
        private RadioButton radioButtonUpdate;
        private RadioButton radioButtonAdd;
        private Button buttonClose;
        private Label labelTransmission;
        private Label labelYear;
        private Label labelColor;
        private Label labelModel;
        private Label labelMarka;
        private TextBox textBoxModel;
        private TextBox textBoxMarka;
        private TextBox textBoxColor;
        private TextBox textBoxYear;
        private TextBox textBoxTransmission;
        private Label labelStatus;
        private TextBox textBoxStatus;
        private Label labelId;
        private TextBox textBoxId;
        private Panel panel2;
        private Label labelDataModification;
    }
}
﻿namespace Прокат
{
    partial class Condition
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panelMenu = new Panel();
            buttonBack = new Button();
            buttonAgreement = new Button();
            buttonPrice = new Button();
            buttonCondition = new Button();
            buttonCar = new Button();
            buttonClients = new Button();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            labelClose = new Label();
            labelCondition = new Label();
            panelCondition = new Panel();
            dataGridView1 = new DataGridView();
            buttonchange = new Button();
            panelMenu.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panelCondition.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panelMenu
            // 
            panelMenu.BackColor = Color.FromArgb(48, 50, 48);
            panelMenu.Controls.Add(buttonBack);
            panelMenu.Controls.Add(buttonAgreement);
            panelMenu.Controls.Add(buttonPrice);
            panelMenu.Controls.Add(buttonCondition);
            panelMenu.Controls.Add(buttonCar);
            panelMenu.Controls.Add(buttonClients);
            panelMenu.Controls.Add(panel1);
            panelMenu.Dock = DockStyle.Left;
            panelMenu.Location = new Point(0, 0);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new Size(156, 657);
            panelMenu.TabIndex = 4;
            // 
            // buttonBack
            // 
            buttonBack.AutoSize = true;
            buttonBack.Cursor = Cursors.Hand;
            buttonBack.Dock = DockStyle.Bottom;
            buttonBack.FlatAppearance.BorderSize = 0;
            buttonBack.FlatStyle = FlatStyle.Flat;
            buttonBack.ForeColor = Color.White;
            buttonBack.Image = Properties.Resources.imgonline_com_ua_Resize_ACyNn6MVD8i;
            buttonBack.ImageAlign = ContentAlignment.MiddleLeft;
            buttonBack.Location = new Point(0, 592);
            buttonBack.Name = "buttonBack";
            buttonBack.Size = new Size(156, 65);
            buttonBack.TabIndex = 6;
            buttonBack.Text = "          На главную";
            buttonBack.UseVisualStyleBackColor = true;
            buttonBack.Click += buttonBack_Click;
            // 
            // buttonAgreement
            // 
            buttonAgreement.AutoSize = true;
            buttonAgreement.Cursor = Cursors.Hand;
            buttonAgreement.Dock = DockStyle.Top;
            buttonAgreement.FlatAppearance.BorderSize = 0;
            buttonAgreement.FlatStyle = FlatStyle.Flat;
            buttonAgreement.ForeColor = Color.White;
            buttonAgreement.Image = Properties.Resources.imgonline_com_ua_Resize_VT0iKZ7F7jZR9oV;
            buttonAgreement.ImageAlign = ContentAlignment.MiddleLeft;
            buttonAgreement.Location = new Point(0, 326);
            buttonAgreement.Name = "buttonAgreement";
            buttonAgreement.Size = new Size(156, 65);
            buttonAgreement.TabIndex = 5;
            buttonAgreement.Text = "         Договоры";
            buttonAgreement.UseVisualStyleBackColor = true;
            buttonAgreement.Click += buttonAgreement_Click;
            // 
            // buttonPrice
            // 
            buttonPrice.AutoSize = true;
            buttonPrice.Cursor = Cursors.Hand;
            buttonPrice.Dock = DockStyle.Top;
            buttonPrice.FlatAppearance.BorderSize = 0;
            buttonPrice.FlatStyle = FlatStyle.Flat;
            buttonPrice.ForeColor = Color.White;
            buttonPrice.Image = Properties.Resources.imgonline_com_ua_Resize_xd3WNqoXyYx3;
            buttonPrice.ImageAlign = ContentAlignment.MiddleLeft;
            buttonPrice.Location = new Point(0, 261);
            buttonPrice.Name = "buttonPrice";
            buttonPrice.Size = new Size(156, 65);
            buttonPrice.TabIndex = 4;
            buttonPrice.Text = "  Цена";
            buttonPrice.UseVisualStyleBackColor = true;
            buttonPrice.Click += buttonPrice_Click;
            // 
            // buttonCondition
            // 
            buttonCondition.AutoSize = true;
            buttonCondition.Cursor = Cursors.Hand;
            buttonCondition.Dock = DockStyle.Top;
            buttonCondition.FlatAppearance.BorderSize = 0;
            buttonCondition.FlatStyle = FlatStyle.Flat;
            buttonCondition.ForeColor = Color.White;
            buttonCondition.Image = Properties.Resources.imgonline_com_ua_Resize_TtxB5FHNg8;
            buttonCondition.ImageAlign = ContentAlignment.MiddleLeft;
            buttonCondition.Location = new Point(0, 196);
            buttonCondition.Name = "buttonCondition";
            buttonCondition.Size = new Size(156, 65);
            buttonCondition.TabIndex = 3;
            buttonCondition.Text = "          Состояние авто";
            buttonCondition.UseVisualStyleBackColor = true;
            buttonCondition.Click += buttonCondition_Click;
            // 
            // buttonCar
            // 
            buttonCar.Cursor = Cursors.Hand;
            buttonCar.Dock = DockStyle.Top;
            buttonCar.FlatAppearance.BorderSize = 0;
            buttonCar.FlatStyle = FlatStyle.Flat;
            buttonCar.ForeColor = Color.White;
            buttonCar.Image = Properties.Resources.imgonline_com_ua_Resize_QEBFWXUsjcfJeKzK;
            buttonCar.ImageAlign = ContentAlignment.MiddleLeft;
            buttonCar.Location = new Point(0, 131);
            buttonCar.Name = "buttonCar";
            buttonCar.Size = new Size(156, 65);
            buttonCar.TabIndex = 2;
            buttonCar.Text = "           Автомобили";
            buttonCar.UseVisualStyleBackColor = true;
            buttonCar.Click += buttonCar_Click;
            // 
            // buttonClients
            // 
            buttonClients.Cursor = Cursors.Hand;
            buttonClients.Dock = DockStyle.Top;
            buttonClients.FlatAppearance.BorderSize = 0;
            buttonClients.FlatStyle = FlatStyle.Flat;
            buttonClients.ForeColor = Color.White;
            buttonClients.Image = Properties.Resources.imgonline_com_ua_Resize_YlzVGv8xwzp1;
            buttonClients.ImageAlign = ContentAlignment.MiddleLeft;
            buttonClients.Location = new Point(0, 66);
            buttonClients.Name = "buttonClients";
            buttonClients.Size = new Size(156, 65);
            buttonClients.TabIndex = 1;
            buttonClients.Text = "    Клиенты";
            buttonClients.UseVisualStyleBackColor = true;
            buttonClients.Click += buttonClients_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Black;
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(156, 66);
            panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.FromArgb(96, 96, 96);
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Image = Properties.Resources._5976949_car_rental_transport_vehicle_icon;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(156, 66);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(15, 20, 73);
            panel2.Controls.Add(labelClose);
            panel2.Controls.Add(labelCondition);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(156, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(922, 66);
            panel2.TabIndex = 5;
            // 
            // labelClose
            // 
            labelClose.Cursor = Cursors.Hand;
            labelClose.Dock = DockStyle.Right;
            labelClose.Font = new Font("PT Sans", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelClose.ForeColor = Color.White;
            labelClose.ImageAlign = ContentAlignment.TopRight;
            labelClose.Location = new Point(900, 0);
            labelClose.Name = "labelClose";
            labelClose.Size = new Size(22, 66);
            labelClose.TabIndex = 10;
            labelClose.Text = "x";
            labelClose.Click += labelClose_Click;
            labelClose.MouseEnter += labelClose_MouseEnter;
            labelClose.MouseLeave += labelClose_MouseLeave;
            // 
            // labelCondition
            // 
            labelCondition.Dock = DockStyle.Fill;
            labelCondition.Font = new Font("Comic Sans MS", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            labelCondition.ForeColor = Color.White;
            labelCondition.Location = new Point(0, 0);
            labelCondition.Name = "labelCondition";
            labelCondition.Size = new Size(922, 66);
            labelCondition.TabIndex = 0;
            labelCondition.Text = "Состояние автомобилей";
            labelCondition.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panelCondition
            // 
            panelCondition.BackColor = Color.FromArgb(96, 96, 96);
            panelCondition.Controls.Add(buttonchange);
            panelCondition.Controls.Add(dataGridView1);
            panelCondition.Dock = DockStyle.Fill;
            panelCondition.Location = new Point(156, 66);
            panelCondition.Name = "panelCondition";
            panelCondition.Size = new Size(922, 591);
            panelCondition.TabIndex = 6;
            panelCondition.MouseDown += panelCondition_MouseDown;
            panelCondition.MouseMove += panelCondition_MouseMove;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(10, 8);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.RowTemplate.Height = 29;
            dataGridView1.Size = new Size(900, 502);
            dataGridView1.TabIndex = 5;
            // 
            // buttonchange
            // 
            buttonchange.FlatAppearance.BorderColor = Color.FromArgb(150, 252, 0);
            buttonchange.FlatAppearance.BorderSize = 2;
            buttonchange.FlatAppearance.MouseDownBackColor = Color.FromArgb(21, 123, 19);
            buttonchange.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonchange.FlatStyle = FlatStyle.Flat;
            buttonchange.Location = new Point(697, 540);
            buttonchange.Name = "buttonchange";
            buttonchange.Size = new Size(213, 36);
            buttonchange.TabIndex = 7;
            buttonchange.Text = "Модификация данных";
            buttonchange.UseVisualStyleBackColor = true;
            buttonchange.Click += buttonchange_Click;
            // 
            // Condition
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1078, 657);
            Controls.Add(panelCondition);
            Controls.Add(panel2);
            Controls.Add(panelMenu);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Condition";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Condition";
            panelMenu.ResumeLayout(false);
            panelMenu.PerformLayout();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panelCondition.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelMenu;
        private Button buttonBack;
        private Button buttonAgreement;
        private Button buttonPrice;
        private Button buttonCondition;
        private Button buttonCar;
        private Button buttonClients;
        private Panel panel1;
        private PictureBox pictureBox1;
        private Panel panel2;
        private Label labelClose;
        private Label labelCondition;
        private Panel panelCondition;
        private DataGridView dataGridView1;
        private Button buttonchange;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Форма "Главная"
namespace Прокат
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void labelClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void labelClose_MouseEnter(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.Red;
        }

        private void labelClose_MouseLeave(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.White;
        }
        Point lastPoint;

        private void panelMain_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panelMain_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void buttonEnterClients_Click(object sender, EventArgs e)
        {
            Clients formClients = new Clients();
            formClients.Show();
            this.Hide();
        }

        private void buttonEnterCars_Click(object sender, EventArgs e)
        {
            Cars formCars = new Cars();
            formCars.Show();
            this.Hide();
        }

        private void buttonConditionCars_Click_1(object sender, EventArgs e)
        {
            Condition formCondition = new Condition();
            formCondition.Show();
            this.Hide();
        }

        private void buttonAddPrice_Click(object sender, EventArgs e)
        {
            Price formPrice = new Price();
            formPrice.Show();
            this.Hide();
        }

        private void buttonAddAgreement_Click(object sender, EventArgs e)
        {
            Agreement formAgreement = new Agreement();
            formAgreement.Show();
            this.Hide();
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
//Форма "Авторизация"
namespace Прокат
{
    public partial class authorization : Form
    {
        public authorization()
        {
            InitializeComponent();
        }

        private void labelClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void labelClose_MouseEnter(object sender, EventArgs e)
        {
            labelClose.ForeColor = Color.Red;
        }

        private void labelClose_MouseLeave(object sender, EventArgs e) 
        {
            labelClose.ForeColor = Color.White;
        }
        Point lastPoint;
        private void panel2_MouseMove(object sender, MouseEventArgs e) //возможность менять положение окна на экране 
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panel2_MouseDown(object sender, MouseEventArgs e) //возможность менять положение окна на экране 
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void buttonEnter_Click(object sender, EventArgs e) //проверка логина и пароля
        {
            string login = textBoxLogin.Text;
            string password = textBoxPassword.Text;

            if (login == "admin" && password == "operator")
            {
                Main formMain = new Main();
                formMain.Show();
                this.Hide();
            }
            else
            {
                textBoxPassword.Text = string.Empty;
                MessageBox.Show("Логин или пароль неверный, попробуйте ещё раз!", "Ошибка");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Форма "Модификация данных автомобилей"
namespace Прокат
{
    public partial class Data_modification_Car : Form
    {
        public static string str = @"Provider=Microsoft.Ace.OLEDB.12.0;Data Source='D:\Study\3 курс\Практика ТРПО\Прокат\БД.accdb';";
        public Data_modification_Car()
        {
            InitializeComponent();
        }
        Point lastPoint;

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }
        private void radioButtonAdd_CheckedChanged(object sender, EventArgs e)
        {
            textBoxId.Visible = true;
            textBoxStatus.Visible = true;
            textBoxModel.Visible = true;
            textBoxMarka.Visible = true;
            textBoxColor.Visible = true;
            textBoxYear.Visible = true;
            textBoxTransmission.Visible = true;

            labelId.Visible = true;
            labelStatus.Visible = true;
            labelModel.Visible = true;
            labelMarka.Visible = true;
            labelColor.Visible = true;
            labelYear.Visible = true;
            labelTransmission.Visible = true;
        }

        private void radioButtonUpdate_CheckedChanged(object sender, EventArgs e)
        {
            textBoxId.Visible = true;
            textBoxStatus.Visible = true;
            textBoxModel.Visible = false;
            textBoxMarka.Visible = false;
            textBoxColor.Visible = false;
            textBoxYear.Visible = false;
            textBoxTransmission.Visible = false;

            labelId.Visible = true;
            labelStatus.Visible = true;
            labelModel.Visible = false;
            labelMarka.Visible = false;
            labelColor.Visible = false;
            labelYear.Visible = false;
            labelTransmission.Visible = false;
        }

        private void radioButtonDelete_CheckedChanged(object sender, EventArgs e)
        {
            textBoxId.Visible = true;
            textBoxStatus.Visible = false;
            textBoxModel.Visible = false;
            textBoxMarka.Visible = false;
            textBoxColor.Visible = false;
            textBoxYear.Visible = false;
            textBoxTransmission.Visible = false;

            labelId.Visible = true;
            labelStatus.Visible = false;
            labelModel.Visible = false;
            labelMarka.Visible = false;
            labelColor.Visible = false;
            labelYear.Visible = false;
            labelTransmission.Visible = false;
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {

            OleDbConnection con = new OleDbConnection(str);
            con.Open();

            if (radioButtonAdd.Checked)
            {
                try
                {
                    string request = "INSERT INTO Автомобили ([id_автомобиля], [Статус], [Модель автомобиля], [Марка автомобиля], [Цвет], [Год выпуска], [Тип коробки передач]) VALUES (@Id, @Status, @Model, @Marka, @Color, @Year, @Transmission)";
                    OleDbCommand command = new OleDbCommand(request, con);
                    command.Parameters.AddWithValue("@Id", textBoxId.Text);
                    command.Parameters.AddWithValue("@Status", textBoxStatus.Text);
                    command.Parameters.AddWithValue("@Model", textBoxModel.Text);
                    command.Parameters.AddWithValue("@Marka", textBoxMarka.Text);
                    command.Parameters.AddWithValue("@Color", textBoxColor.Text);
                    command.Parameters.AddWithValue("@Year", textBoxYear.Text);
                    command.Parameters.AddWithValue("@Transmission", textBoxTransmission.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно сохранены и обновлены в базе данных.", "Сообщение");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения данных: " + ex.Message);
                }

            }
            else if (radioButtonUpdate.Checked)
            {
                try
                {
                    string request = "UPDATE Автомобили SET [Статус] = @Status WHERE [id_автомобиля] = @Id";
                    OleDbCommand command = new OleDbCommand(request, con);
                    command.Parameters.AddWithValue("@Status", textBoxStatus.Text);
                    command.Parameters.AddWithValue("@Id", textBoxId.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно сохранены и обновлены в базе данных.", "Сообщение");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения данных: " + ex.Message);
                }
            }
            else if (radioButtonDelete.Checked)
            {
                try
                {
                    string request = "DELETE FROM Автомобили WHERE [id_автомобиля] = @Id";
                    OleDbCommand command = new OleDbCommand(request, con);
                    command.Parameters.AddWithValue("@Id", textBoxId.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно сохранены и обновлены в базе данных.", "Сообщение");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения данных: " + ex.Message);
                }
            }

            con.Close();
        }
    }
}

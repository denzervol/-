﻿namespace Прокат
{
    partial class Data_Modification_Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            radioButtonDelete = new RadioButton();
            buttonEnter = new Button();
            radioButtonUpdate = new RadioButton();
            radioButtonAdd = new RadioButton();
            buttonClose = new Button();
            labelDriver = new Label();
            labelTelephone = new Label();
            labelPasport = new Label();
            textBoxPasport = new TextBox();
            textBoxTelephone = new TextBox();
            textBoxDriver = new TextBox();
            labelFIO = new Label();
            textBoxFIO = new TextBox();
            labelId = new Label();
            textBoxId = new TextBox();
            panel2 = new Panel();
            labelDataModification = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(96, 96, 96);
            panel1.Controls.Add(radioButtonDelete);
            panel1.Controls.Add(buttonEnter);
            panel1.Controls.Add(radioButtonUpdate);
            panel1.Controls.Add(radioButtonAdd);
            panel1.Controls.Add(buttonClose);
            panel1.Controls.Add(labelDriver);
            panel1.Controls.Add(labelTelephone);
            panel1.Controls.Add(labelPasport);
            panel1.Controls.Add(textBoxPasport);
            panel1.Controls.Add(textBoxTelephone);
            panel1.Controls.Add(textBoxDriver);
            panel1.Controls.Add(labelFIO);
            panel1.Controls.Add(textBoxFIO);
            panel1.Controls.Add(labelId);
            panel1.Controls.Add(textBoxId);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(887, 601);
            panel1.TabIndex = 1;
            panel1.MouseDown += panel1_MouseDown;
            panel1.MouseMove += panel1_MouseMove;
            // 
            // radioButtonDelete
            // 
            radioButtonDelete.AutoSize = true;
            radioButtonDelete.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButtonDelete.Location = new Point(653, 102);
            radioButtonDelete.Name = "radioButtonDelete";
            radioButtonDelete.Size = new Size(196, 32);
            radioButtonDelete.TabIndex = 7;
            radioButtonDelete.TabStop = true;
            radioButtonDelete.Text = "Удалить клиента";
            radioButtonDelete.UseVisualStyleBackColor = true;
            radioButtonDelete.CheckedChanged += radioButtonDelete_CheckedChanged_1;
            // 
            // buttonEnter
            // 
            buttonEnter.FlatAppearance.BorderColor = Color.FromArgb(150, 252, 0);
            buttonEnter.FlatAppearance.BorderSize = 2;
            buttonEnter.FlatAppearance.MouseDownBackColor = Color.FromArgb(21, 123, 19);
            buttonEnter.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonEnter.FlatStyle = FlatStyle.Flat;
            buttonEnter.Font = new Font("Comic Sans MS", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            buttonEnter.Location = new Point(622, 524);
            buttonEnter.Name = "buttonEnter";
            buttonEnter.Size = new Size(191, 32);
            buttonEnter.TabIndex = 20;
            buttonEnter.Text = "Сохранить";
            buttonEnter.UseVisualStyleBackColor = true;
            buttonEnter.Click += buttonEnter_Click;
            // 
            // radioButtonUpdate
            // 
            radioButtonUpdate.AutoSize = true;
            radioButtonUpdate.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButtonUpdate.Location = new Point(330, 102);
            radioButtonUpdate.Name = "radioButtonUpdate";
            radioButtonUpdate.Size = new Size(202, 32);
            radioButtonUpdate.TabIndex = 6;
            radioButtonUpdate.TabStop = true;
            radioButtonUpdate.Text = "Обновить данные";
            radioButtonUpdate.UseVisualStyleBackColor = true;
            radioButtonUpdate.CheckedChanged += radioButtonUpdate_CheckedChanged;
            // 
            // radioButtonAdd
            // 
            radioButtonAdd.AutoSize = true;
            radioButtonAdd.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButtonAdd.Location = new Point(43, 102);
            radioButtonAdd.Name = "radioButtonAdd";
            radioButtonAdd.Size = new Size(206, 32);
            radioButtonAdd.TabIndex = 5;
            radioButtonAdd.TabStop = true;
            radioButtonAdd.Text = "Добавить клиента";
            radioButtonAdd.UseVisualStyleBackColor = true;
            radioButtonAdd.CheckedChanged += radioButtonAdd_CheckedChanged;
            // 
            // buttonClose
            // 
            buttonClose.FlatAppearance.BorderColor = Color.FromArgb(150, 252, 0);
            buttonClose.FlatAppearance.BorderSize = 2;
            buttonClose.FlatAppearance.MouseDownBackColor = Color.FromArgb(21, 123, 19);
            buttonClose.FlatAppearance.MouseOverBackColor = Color.FromArgb(150, 252, 0);
            buttonClose.FlatStyle = FlatStyle.Flat;
            buttonClose.Font = new Font("Comic Sans MS", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            buttonClose.Location = new Point(43, 524);
            buttonClose.Name = "buttonClose";
            buttonClose.Size = new Size(191, 32);
            buttonClose.TabIndex = 19;
            buttonClose.Text = "Закрыть";
            buttonClose.UseVisualStyleBackColor = true;
            buttonClose.Click += buttonClose_Click;
            // 
            // labelDriver
            // 
            labelDriver.AutoSize = true;
            labelDriver.Font = new Font("Comic Sans MS", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            labelDriver.Location = new Point(60, 420);
            labelDriver.Name = "labelDriver";
            labelDriver.Size = new Size(351, 31);
            labelDriver.TabIndex = 15;
            labelDriver.Text = "Категория водительских прав";
            // 
            // labelTelephone
            // 
            labelTelephone.AutoSize = true;
            labelTelephone.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelTelephone.Location = new Point(311, 359);
            labelTelephone.Name = "labelTelephone";
            labelTelephone.Size = new Size(100, 28);
            labelTelephone.TabIndex = 14;
            labelTelephone.Text = "Телефон";
            // 
            // labelPasport
            // 
            labelPasport.AutoSize = true;
            labelPasport.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelPasport.Location = new Point(201, 301);
            labelPasport.Name = "labelPasport";
            labelPasport.Size = new Size(210, 28);
            labelPasport.TabIndex = 13;
            labelPasport.Text = "Паспортные данные";
            // 
            // textBoxPasport
            // 
            textBoxPasport.Location = new Point(455, 301);
            textBoxPasport.Name = "textBoxPasport";
            textBoxPasport.Size = new Size(358, 27);
            textBoxPasport.TabIndex = 12;
            // 
            // textBoxTelephone
            // 
            textBoxTelephone.Location = new Point(455, 359);
            textBoxTelephone.Name = "textBoxTelephone";
            textBoxTelephone.Size = new Size(358, 27);
            textBoxTelephone.TabIndex = 11;
            // 
            // textBoxDriver
            // 
            textBoxDriver.Location = new Point(455, 420);
            textBoxDriver.Name = "textBoxDriver";
            textBoxDriver.Size = new Size(358, 27);
            textBoxDriver.TabIndex = 10;
            // 
            // labelFIO
            // 
            labelFIO.AutoSize = true;
            labelFIO.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelFIO.Location = new Point(355, 240);
            labelFIO.Name = "labelFIO";
            labelFIO.Size = new Size(56, 28);
            labelFIO.TabIndex = 4;
            labelFIO.Text = "ФИО";
            // 
            // textBoxFIO
            // 
            textBoxFIO.Location = new Point(455, 240);
            textBoxFIO.Name = "textBoxFIO";
            textBoxFIO.Size = new Size(358, 27);
            textBoxFIO.TabIndex = 3;
            // 
            // labelId
            // 
            labelId.AutoSize = true;
            labelId.Font = new Font("Comic Sans MS", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelId.Location = new Point(293, 184);
            labelId.Name = "labelId";
            labelId.Size = new Size(118, 28);
            labelId.TabIndex = 2;
            labelId.Text = "Id клиента";
            // 
            // textBoxId
            // 
            textBoxId.Location = new Point(455, 182);
            textBoxId.Name = "textBoxId";
            textBoxId.Size = new Size(358, 27);
            textBoxId.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(48, 50, 48);
            panel2.Controls.Add(labelDataModification);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(887, 77);
            panel2.TabIndex = 0;
            // 
            // labelDataModification
            // 
            labelDataModification.Dock = DockStyle.Fill;
            labelDataModification.Font = new Font("Comic Sans MS", 24F, FontStyle.Regular, GraphicsUnit.Point);
            labelDataModification.ForeColor = Color.White;
            labelDataModification.Location = new Point(0, 0);
            labelDataModification.Name = "labelDataModification";
            labelDataModification.Size = new Size(887, 77);
            labelDataModification.TabIndex = 0;
            labelDataModification.Text = "Модификация данных клиентов";
            labelDataModification.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Data_Modification_Client
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(887, 601);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Data_Modification_Client";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Data_Modification_Client";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private RadioButton radioButtonDelete;
        private Button buttonEnter;
        private RadioButton radioButtonUpdate;
        private RadioButton radioButtonAdd;
        private Button buttonClose;
        private Label labelDriver;
        private Label labelTelephone;
        private Label labelPasport;
        private TextBox textBoxPasport;
        private TextBox textBoxTelephone;
        private TextBox textBoxDriver;
        private Label labelFIO;
        private TextBox textBoxFIO;
        private Label labelId;
        private TextBox textBoxId;
        private Panel panel2;
        private Label labelDataModification;
    }
}
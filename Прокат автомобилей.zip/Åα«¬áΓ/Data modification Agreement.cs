﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Windows.Forms.VisualStyles;
using System.Reflection.Emit;
//Форма "модификация данных договоров"
namespace Прокат
{
    public partial class Data_modification_Agreement : Form
    {
        public static string str = @"Provider=Microsoft.Ace.OLEDB.12.0;Data Source='D:\Study\3 курс\Практика ТРПО\Прокат\БД.accdb';";
        //string comm = "Select * from Аренда";
        public Data_modification_Agreement()
        {
            InitializeComponent();
        }

        Point lastPoint;

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void radioButtonAdd_CheckedChanged(object sender, EventArgs e)
        {
            textBoxIdClient.Visible = true;
            textBoxIdCar.Visible = true;
            textBoxStart.Visible = true;
            textBoxEnd.Visible = true;

            labelIdClient.Visible = true;
            labelIdCar.Visible = true;
            labelStart.Visible = true;
            labelEnd.Visible = true;
        }
        private void radioButtonDelete_CheckedChanged(object sender, EventArgs e)
        {
            textBoxIdClient.Visible = false;
            textBoxIdCar.Visible = true;
            textBoxStart.Visible = true;
            textBoxEnd.Visible = false;

            labelIdClient.Visible = false;
            labelIdCar.Visible = true;
            labelStart.Visible = true;
            labelEnd.Visible = false;
        }

        private void buttonEnter_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection(str);
            con.Open();

            if (radioButtonAdd.Checked)
            {
                try
                {
                    string request = "INSERT INTO Аренда ([id_клиента], [id_автомобиля], [Дата заключения], [Дата окончания]) VALUES (@IdClient, @IdCar, @Start, @End)";
                    OleDbCommand command = new OleDbCommand(request, con);
                    command.Parameters.AddWithValue("@IdClient", textBoxIdClient.Text);
                    command.Parameters.AddWithValue("@IdCar", textBoxIdCar.Text);
                    command.Parameters.AddWithValue("@Start", textBoxStart.Text);
                    command.Parameters.AddWithValue("@End", textBoxEnd.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно сохранены и обновлены в базе данных.", "Сообщение");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения данных: " + ex.Message);
                }

            }
            else if (radioButtonDelete.Checked)
            {
                try
                {
                    string request = "DELETE FROM Аренда WHERE [id_автомобиля] = @IdCar AND [Дата заключения] = @Start";
                    OleDbCommand command = new OleDbCommand(request, con);
                    command.Parameters.AddWithValue("@IdCar", textBoxIdCar.Text);
                    command.Parameters.AddWithValue("@Start", textBoxStart.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно сохранены и обновлены в базе данных.", "Сообщение");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка сохранения данных: " + ex.Message);
                }
            }

            con.Close();
        }
    }
}
